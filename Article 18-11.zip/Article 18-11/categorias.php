<?php

include("conecta.php");
include("header.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <link rel="stylesheet" href="user.css">
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" type="text/css" href="css/header.css"><link rel="stylesheet" type="text/css" href="css/categoriaS.css">
        <script src="https://kit.fontawesome.com/e0f6b52dac.js" crossorigin="anonymous"></script>
        <!-- CSS only -->
        <!-- JavaScript Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    </head>
</head>
<body>
    <div class="cachota">
    <br>
    <br>
    <div class="categoria">
    <h1> HTML </h1>
       O HTML é o componente básico da web, ele permite inserir o conteúdo e estabelecer a estrutura básica de um website. Portanto, ele serve para dar significado e organizar as informações de uma página na web. Sem isso, o navegador não saberia exibir textos como elementos ou carregar imagens e outros conteúdos.
        <h1> PHP </h1>
    O PHP (um acrônimo recursivo para PHP: Hypertext Preprocessor ) é uma linguagem de script open source de uso geral, muito utilizada, e especialmente adequada para o desenvolvimento web e que pode ser embutida dentro do HTML.

        <h1>CSS</h1>
    O CSS é uma linguagem de design gráfico escrita dentro do código HTML de um site e que permite criar páginas de forma mais precisa, além de aplicar estilos, como cores, margens, formas, tipos de letras etc.

        <h1>JavaScript</h1>
        JavaScript é a linguagem de programação usada para adicionar interatividade ao seu site (por exemplo: jogos, respostas quando botões são pressionados ou dados são inseridos em formulários, estilo dinâmico, animações).
</div>
<div class="exemplo">
    <br>
    <br>
        <h2>HTML Exemplo:</h2>
        < ! DOCTYPE html >
        <br>
        < HTML >
        <br>
        < body >
        <br>
        < h1 >HELLO WORLD!! < / h1 >
        <br>
        < body >
        <br>
        < / HTML >
        <br>
        <br>
        <br>

        <h2>PHP Exemplo:</h2>
        < ! DOCTYPE html >
        <br>
        < HTML >
        <br>
        < body >
        <br>
        < ? php
        <br>
        echo "Hello World!";
        <br>
        ? >
        <br>
        < / body >
        <br>
        < / HTML >
        <br>
        <br>

        <h2>CSS Exemplo:</h2>
        body {
        <br>
          background-color: lightblue;
          <br>
        }
        <br>
        h1 {
        <br>
          color: white;
        <br>
          text-align: center;
        <br>
        }
        <br>
        <br>
        <br>
        <h2>JavaScript Exemplo:</h2>
    </div>
    <div class="cachota">
    
   </body>
</html>