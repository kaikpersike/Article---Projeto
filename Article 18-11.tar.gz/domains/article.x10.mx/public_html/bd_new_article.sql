-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2022 at 02:14 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bd_new_article`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_comentario`
--

CREATE TABLE `tb_comentario` (
  `cd_comentario` int(11) NOT NULL,
  `id_post` int(100) DEFAULT NULL,
  `nm_comentario_nome` varchar(100) DEFAULT NULL,
  `ds_comentario` text DEFAULT NULL,
  `ds_data` varchar(100) DEFAULT NULL,
  `ds_hora` varchar(100) DEFAULT NULL,
  `id_imagem` varchar(250) NOT NULL,
  `id_user_comentario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_comentario`
--

INSERT INTO `tb_comentario` (`cd_comentario`, `id_post`, `nm_comentario_nome`, `ds_comentario`, `ds_data`, `ds_hora`, `id_imagem`, `id_user_comentario`) VALUES
(228, 85, 'kaik', '<p>sdffsf</p>', '05/11/2022', '02:35', 'imagens/semfoto.png', 46),
(229, 85, 'kaik', '<p>fsdfsfd</p>', '05/11/2022', '02:35', 'imagens/semfoto.png', 46),
(231, 85, 'jam jam', '<p>gdfdgdsgds</p>', '05/11/2022', '04:00', 'imagens/uploads/gsdfgfdgsd.jpg', 47),
(232, 85, 'jam jam', '<p>gdsfsd</p>', '05/11/2022', '04:00', 'imagens/uploads/gsdfgfdgsd.jpg', 47);

-- --------------------------------------------------------

--
-- Table structure for table `tb_curtir`
--

CREATE TABLE `tb_curtir` (
  `cd_curtir` int(11) NOT NULL,
  `nr_curtir` int(11) NOT NULL,
  `id_post_curtir` int(11) DEFAULT NULL,
  `id_user_curtir` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_curtir`
--

INSERT INTO `tb_curtir` (`cd_curtir`, `nr_curtir`, `id_post_curtir`, `id_user_curtir`) VALUES
(80, 1, 79, 46);

-- --------------------------------------------------------

--
-- Table structure for table `tb_curtir_duv`
--

CREATE TABLE `tb_curtir_duv` (
  `cd_curtir_duv` int(11) NOT NULL,
  `nr_curtir_duv` int(11) DEFAULT NULL,
  `id_post_duv` int(11) DEFAULT NULL,
  `id_user_duv` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_curtir_duv`
--

INSERT INTO `tb_curtir_duv` (`cd_curtir_duv`, `nr_curtir_duv`, `id_post_duv`, `id_user_duv`) VALUES
(26, 1, 73, 46);

-- --------------------------------------------------------

--
-- Table structure for table `tb_duvida_comentario`
--

CREATE TABLE `tb_duvida_comentario` (
  `cd_duv_comentario` int(11) NOT NULL,
  `id_post_duv` int(11) DEFAULT NULL,
  `nm_nome_duv` varchar(100) DEFAULT NULL,
  `ds_comentario_duv` text DEFAULT NULL,
  `ds_data_duv` varchar(100) DEFAULT NULL,
  `ds_hora_duv` varchar(100) DEFAULT NULL,
  `id_img_duvida` varchar(250) DEFAULT NULL,
  `id_duv_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_duvida_comentario`
--

INSERT INTO `tb_duvida_comentario` (`cd_duv_comentario`, `id_post_duv`, `nm_nome_duv`, `ds_comentario_duv`, `ds_data_duv`, `ds_hora_duv`, `id_img_duvida`, `id_duv_user`) VALUES
(50, 73, 'kaik', '<p>sdfsfsf</p>', '06/11/2022', '10:10', 'imagens/semfoto.png', 46),
(51, 73, 'kaik', '<p>Teste 2.0</p>', '06/11/2022', '10:13', 'imagens/semfoto.png', 46),
(52, 73, 'jam jam', '<p>sdfdsffs</p>', '06/11/2022', '10:13', 'imagens/uploads/gsdfgfdgsd.jpg', 47),
(53, 73, 'jam jam', '<p>sdfdfsfsfsfsf</p>', '06/11/2022', '10:13', 'imagens/uploads/gsdfgfdgsd.jpg', 47),
(54, 73, 'jam jam', '<p>sdffsfs</p>', '06/11/2022', '10:13', 'imagens/uploads/gsdfgfdgsd.jpg', 47);

-- --------------------------------------------------------

--
-- Table structure for table `tb_notificacao`
--

CREATE TABLE `tb_notificacao` (
  `cd_notificacao` int(11) NOT NULL,
  `ds_notificacao` varchar(250) DEFAULT NULL,
  `nm_titulo_not` varchar(100) DEFAULT NULL,
  `ds_data_not` varchar(100) NOT NULL,
  `ds_hora_not` varchar(100) NOT NULL,
  `id_user_not` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_notificacao`
--

INSERT INTO `tb_notificacao` (`cd_notificacao`, `ds_notificacao`, `nm_titulo_not`, `ds_data_not`, `ds_hora_not`, `id_user_not`) VALUES
(32, 'Sua dúvida foi enviada. Agora, só esperar as respostas!', 'Pergunta enviada!', '05/11/2022', ' 15:08:36', 47);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pergunta`
--

CREATE TABLE `tb_pergunta` (
  `cd_pergunta` int(11) NOT NULL,
  `nm_nome` varchar(100) DEFAULT NULL,
  `ds_pergunta` varchar(250) DEFAULT NULL,
  `ds_data` int(11) NOT NULL,
  `ds_hora` int(11) NOT NULL,
  `ds_titulo` varchar(100) NOT NULL,
  `id_user_perg` int(11) NOT NULL,
  `ds_linguagem_duv` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pergunta`
--

INSERT INTO `tb_pergunta` (`cd_pergunta`, `nm_nome`, `ds_pergunta`, `ds_data`, `ds_hora`, `ds_titulo`, `id_user_perg`, `ds_linguagem_duv`) VALUES
(72, 'jam jam', '<p>ddddddfsd</p>', 2, 8, 'sfdgsd', 47, '1'),
(73, 'jam jam', '<p>estsets</p>', 5, 15, 'teste', 47, '1');

-- --------------------------------------------------------

--
-- Table structure for table `tb_post`
--

CREATE TABLE `tb_post` (
  `cd_post` int(11) NOT NULL,
  `ds_titulo` varchar(100) DEFAULT NULL,
  `ds_texto` text DEFAULT NULL,
  `im_imagem` varchar(200) DEFAULT NULL,
  `ds_data` varchar(100) DEFAULT NULL,
  `ds_hora` varchar(100) DEFAULT NULL,
  `nm_postador` varchar(100) DEFAULT NULL,
  `ds_linguagem` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `ds_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_post`
--

INSERT INTO `tb_post` (`cd_post`, `ds_titulo`, `ds_texto`, `im_imagem`, `ds_data`, `ds_hora`, `nm_postador`, `ds_linguagem`, `id_user`, `ds_status`) VALUES
(85, 'sdfdfsf', '<p>fssffs</p>', 'imagens/uploads/Dicionario-Tech-1152x648.png', '28/10/2022', ' 12:06:58', 'kaik', '1', 46, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tb_resposta`
--

CREATE TABLE `tb_resposta` (
  `cd_resposta` int(11) NOT NULL,
  `nm_usuario_resposta` varchar(250) NOT NULL,
  `ds_resposta` text DEFAULT NULL,
  `id_comentario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_resposta`
--

INSERT INTO `tb_resposta` (`cd_resposta`, `nm_usuario_resposta`, `ds_resposta`, `id_comentario`) VALUES
(130, 'kaik', '', 204);

-- --------------------------------------------------------

--
-- Table structure for table `tb_usuario`
--

CREATE TABLE `tb_usuario` (
  `cd_usuario` int(11) NOT NULL,
  `nm_usuario` varchar(100) DEFAULT NULL,
  `nr_rm` char(8) DEFAULT NULL,
  `ds_email` varchar(100) DEFAULT NULL,
  `ds_senha` varchar(50) DEFAULT NULL,
  `nr_serie` int(11) DEFAULT NULL,
  `nr_nivel` int(11) DEFAULT NULL,
  `ds_img` varchar(250) NOT NULL,
  `ds_banner` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_usuario`
--

INSERT INTO `tb_usuario` (`cd_usuario`, `nm_usuario`, `nr_rm`, `ds_email`, `ds_senha`, `nr_serie`, `nr_nivel`, `ds_img`, `ds_banner`) VALUES
(45, 'Sarah de Almeida', '12345', 'sara@gmail.com', '123', 3, 1, 'imagens/uploads/stalin1952bb.webp', 'imagens/test.png'),
(46, 'kaik', '123445', 'kaik@com', '123', 2, 2, 'imagens/semfoto.png', 'imagens/test.png'),
(47, 'jam jam', '321321', 'jam@jam', '321', 1, 1, 'imagens/uploads/gsdfgfdgsd.jpg', 'imagens/test.png'),
(50, 'dsffsf', '3242', 'sdfdfs@com', '123', 1, 1, 'imagens/semfoto.png', 'imagens/test.png'),
(51, 'Joao', '12331', 'jao@jao', '321', 1, 1, 'imagens/semfoto.png', 'imagens/test.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_comentario`
--
ALTER TABLE `tb_comentario`
  ADD PRIMARY KEY (`cd_comentario`);

--
-- Indexes for table `tb_curtir`
--
ALTER TABLE `tb_curtir`
  ADD PRIMARY KEY (`cd_curtir`);

--
-- Indexes for table `tb_curtir_duv`
--
ALTER TABLE `tb_curtir_duv`
  ADD PRIMARY KEY (`cd_curtir_duv`);

--
-- Indexes for table `tb_duvida_comentario`
--
ALTER TABLE `tb_duvida_comentario`
  ADD PRIMARY KEY (`cd_duv_comentario`);

--
-- Indexes for table `tb_notificacao`
--
ALTER TABLE `tb_notificacao`
  ADD PRIMARY KEY (`cd_notificacao`);

--
-- Indexes for table `tb_pergunta`
--
ALTER TABLE `tb_pergunta`
  ADD PRIMARY KEY (`cd_pergunta`);

--
-- Indexes for table `tb_post`
--
ALTER TABLE `tb_post`
  ADD PRIMARY KEY (`cd_post`);

--
-- Indexes for table `tb_resposta`
--
ALTER TABLE `tb_resposta`
  ADD PRIMARY KEY (`cd_resposta`);

--
-- Indexes for table `tb_usuario`
--
ALTER TABLE `tb_usuario`
  ADD PRIMARY KEY (`cd_usuario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_comentario`
--
ALTER TABLE `tb_comentario`
  MODIFY `cd_comentario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=233;

--
-- AUTO_INCREMENT for table `tb_curtir`
--
ALTER TABLE `tb_curtir`
  MODIFY `cd_curtir` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `tb_curtir_duv`
--
ALTER TABLE `tb_curtir_duv`
  MODIFY `cd_curtir_duv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tb_duvida_comentario`
--
ALTER TABLE `tb_duvida_comentario`
  MODIFY `cd_duv_comentario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `tb_notificacao`
--
ALTER TABLE `tb_notificacao`
  MODIFY `cd_notificacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tb_pergunta`
--
ALTER TABLE `tb_pergunta`
  MODIFY `cd_pergunta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `tb_post`
--
ALTER TABLE `tb_post`
  MODIFY `cd_post` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `tb_resposta`
--
ALTER TABLE `tb_resposta`
  MODIFY `cd_resposta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `tb_usuario`
--
ALTER TABLE `tb_usuario`
  MODIFY `cd_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
