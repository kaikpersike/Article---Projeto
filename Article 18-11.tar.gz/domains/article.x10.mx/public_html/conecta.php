<?php


    // Inicio conexão...

    $mysqli = new mysqli('localhost', 'rzmardhj_teste', 'etecitanhaem', 'rzmardhj_teste');
    if($mysqli -> connect_errno){
        echo $mysqli -> connect->error;
    }

    session_start();

        

?>


