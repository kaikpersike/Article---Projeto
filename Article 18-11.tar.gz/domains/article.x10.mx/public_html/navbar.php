<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/nav.css">
	<meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<title>Navbar</title>
</head>
<body>
        <nav id="nav">  
            <table class="tbZebra">
                <thread>
                    <tr>
                     <th>categorias</th>
                    </tr>
                </thread>
                    <tbody>
                        <tr>
                        <td>categoria</td>
                        </tr>
                        <tr>
                        <td>categoria</td>
                        </tr>
                        <tr>
                        <td>categoria</td>
                        </tr>
                        <tr>
                        <td>categoria</td>
                        </tr>
                        <tr>
                        <td>categoria</td>
                        </tr>
                        <tr>
                        <td>categoria</td>
                        </tr>
                        <tr>
                        <td>categoria</td>
                        </tr>
                        <tr>
                        <td>categoria</td>
                        </tr>
                        <tr>
                        <td>categoria</td>
                        </tr>
                    </tbody>
            </table>
        </nav>  
